package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;


@Entity
public class Vehcile {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int vehcileId;
	

	@Column(name = "vehcile_no")
	private String vehcileNo;
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "vehcileId", referencedColumnName = "vehcileId")
	private List<Person_Vehcile> personVehcile = new ArrayList<>();


	public Vehcile(String vehcileNo) {
		super();
		this.vehcileNo = vehcileNo;
	}


	public int getVehcileId() {
		return vehcileId;
	}


	public void setVehcileId(int vehcileId) {
		this.vehcileId = vehcileId;
	}


	public String getVehcileNo() {
		return vehcileNo;
	}


	public void setVehcileNo(String vehcileNo) {
		this.vehcileNo = vehcileNo;
	}


	public List<Person_Vehcile> getPersonVehcile() {
		return personVehcile;
	}


	public void setPersonVehcile(List<Person_Vehcile> personVehcile) {
		this.personVehcile = personVehcile;
	}


	@Override
	public String toString() {
		return "Vehcile [vehcileId=" + vehcileId + ", vehcileNo=" + vehcileNo + ", personVehcile=" + personVehcile
				+ "]";
	}
	
	

}
