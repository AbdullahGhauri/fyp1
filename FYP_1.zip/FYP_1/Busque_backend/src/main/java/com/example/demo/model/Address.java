package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int addressId;
	

	@Column(name = "country")
	private String country;
	

	@Column(name = "province")
	private String province;
	

	@Column(name = "city")
	private String city;
	

	@Column(name = "town")
	private String town;
	

	@Column(name = "address_value")
	private String addressValue;


	public Address(String country, String province, String city, String town, String addressValue) {
		super();
		this.country = country;
		this.province = province;
		this.city = city;
		this.town = town;
		this.addressValue = addressValue;
	}


	public int getAddressId() {
		return addressId;
	}


	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getProvince() {
		return province;
	}


	public void setProvince(String province) {
		this.province = province;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getTown() {
		return town;
	}


	public void setTown(String town) {
		this.town = town;
	}


	public String getAddressValue() {
		return addressValue;
	}


	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}


	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", country=" + country + ", province=" + province + ", city=" + city
				+ ", town=" + town + ", addressValue=" + addressValue + "]";
	}
	
	
	
	
	

}
