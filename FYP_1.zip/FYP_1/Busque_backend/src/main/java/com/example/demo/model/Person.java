package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class Person {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int personID;
	

	@Column(name = "firstname")
	private String firstName;
	

	@Column(name = "lasttname")
	private String lastName;
	

	@Column(name = "cnic")
	private String CNIC;
	

	@Column(name = "contact_no")
	private String contactNo;
	
	@OneToOne(fetch = FetchType.LAZY, optional = false,cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "personId", referencedColumnName = "personID")
	private List<Address> address = new ArrayList<>();


	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "personId", referencedColumnName = "personID")
	private List<Person_Vehcile> personVehcile = new ArrayList<>();
	
	
	public Person() {}
	public Person(String firstName, String lastName, String cNIC, String contactNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		CNIC = cNIC;
		this.contactNo = contactNo;
	}
	
	


	public int getPersonID() {
		return personID;
	}


	public void setPersonID(int personID) {
		this.personID = personID;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getCNIC() {
		return CNIC;
	}


	public void setCNIC(String cNIC) {
		CNIC = cNIC;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public List<Address> getAddress() {
		return address;
	}


	public void setAddress(List<Address> address) {
		this.address = address;
	}




	public List<Person_Vehcile> getPersonVehcile() {
		return personVehcile;
	}




	public void setPersonVehcile(List<Person_Vehcile> personVehcile) {
		this.personVehcile = personVehcile;
	}




	public User getUser() {
		return user;
	}




	public void setUser(User user) {
		this.user = user;
	}




	@Override
	public String toString() {
		return "Person [personID=" + personID + ", firstName=" + firstName + ", lastName=" + lastName + ", CNIC=" + CNIC
				+ ", contactNo=" + contactNo + ", user=" + user + ", address=" + address + ", personVehcile="
				+ personVehcile + "]";
	}

	
	

}
