package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;


@Entity
public class Route {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int routeId;
	

	@Column(name = "route_name")
	private String routeName;
	

	@Column(name = "route_active")
	private boolean routeActive;
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "routeId", referencedColumnName = "routeId")
	private List<RoutePlace> routePlace = new ArrayList<>();


	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "routeId", referencedColumnName = "routeId")
	private List<PersonVehcileRoute> personVehcileRoute = new ArrayList<>();

	public Route(String routeName, boolean routeActive) {
		super();
		this.routeName = routeName;
		this.routeActive = routeActive;
	}


	public int getRouteId() {
		return routeId;
	}


	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}


	public String getRouteName() {
		return routeName;
	}


	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}


	public boolean isRouteActive() {
		return routeActive;
	}


	public void setRouteActive(boolean routeActive) {
		this.routeActive = routeActive;
	}


	public List<PersonVehcileRoute> getPersonVehcileRoute() {
		return personVehcileRoute;
	}


	public void setPersonVehcileRoute(List<PersonVehcileRoute> personVehcileRoute) {
		this.personVehcileRoute = personVehcileRoute;
	}


	public List<RoutePlace> getRoutePlace() {
		return routePlace;
	}


	public void setRoutePlace(List<RoutePlace> routePlace) {
		this.routePlace = routePlace;
	}


	@Override
	public String toString() {
		return "Route [routeId=" + routeId + ", routeName=" + routeName + ", routeActive=" + routeActive
				+ ", personVehcileRoute=" + personVehcileRoute + "]";
	}


	
	
	
}
