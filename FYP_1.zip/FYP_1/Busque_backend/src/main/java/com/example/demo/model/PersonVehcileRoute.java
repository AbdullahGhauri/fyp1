package com.example.demo.model;

import javax.persistence.*;

@Entity
public class PersonVehcileRoute {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int personVehcileRouteId;

	public PersonVehcileRoute() {
		super();
	}

	public int getPersonVehcileRouteId() {
		return personVehcileRouteId;
	}

	public void setPersonVehcileRouteId(int personVehcileRouteId) {
		this.personVehcileRouteId = personVehcileRouteId;
	}

	@Override
	public String toString() {
		return "PersonVehcileRoute [personVehcileRouteId=" + personVehcileRouteId + "]";
	}
	
	
	

}
