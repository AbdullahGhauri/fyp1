package com.example.demo.controllers;

import java.awt.PageAttributes.MediaType;
import java.nio.file.Path;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Person;
import com.example.demo.model.User;
import com.example.demo.repository.AddressRepository;
import com.example.demo.repository.PersonRepository;
import com.example.demo.repository.UserRepository;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@RestController
@RequestMapping("/test")
public class TestController {
	

	@Autowired
	UserRepository userrepository;
	@Autowired
	PersonRepository personRepository;
	@Autowired
	AddressRepository addressRepository;
	
	/*@GetMapping
	public ResponseEntity<String> getTestData() {
		
		return ResponseEntity.ok("This is test data");
	}*/
	
	@GetMapping("/getUser")
	public List<User> getUser() {
	
		List<User> allUser = userrepository.findAll();
		return allUser;
		
	}
	
	@PostMapping(path="/addUser", consumes = {"application/json"})
	public User createUser(@RequestBody User user) {
		userrepository.save(user);
		return user;
	}
	
	
	
	@PostMapping(path="/addPerson", consumes = {"application/json"})
	public Person createPerson(@RequestBody Person person) {
		
		personRepository.save(person);
		return person;
	}
	@PostMapping(path="/userAuthenticatio", consumes = {"application/json"})
	public String createPerson(@RequestBody User user) {
		List<Integer> userData = userrepository.findbyUserName(user.getUserName(),user.getPassword() );
		if(userData.size() != 0) {
			return "ok";
		}
		return "false ";
	}
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@GetMapping("/getPerson")
	public List<Person> getPerson() {
		List<Person> allUser = personRepository.findAll();
		return allUser;
		
	}
	
}
