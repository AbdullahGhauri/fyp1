package com.example.demo.model;

import javax.persistence.*;

@Entity
public class RoutePlace {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int routePlaceId;


	@Column(name = "sequence")
	private int sequence;


	public RoutePlace(int sequence) {
		super();
		this.sequence = sequence;
	}


	public int getRoutePlaceId() {
		return routePlaceId;
	}


	public void setRoutePlaceId(int routePlaceId) {
		this.routePlaceId = routePlaceId;
	}


	public int getSequence() {
		return sequence;
	}


	public void setSequence(int sequence) {
		this.sequence = sequence;
	}


	@Override
	public String toString() {
		return "RoutePlace [routePlaceId=" + routePlaceId + ", sequence=" + sequence + "]";
	}
	
	
}
