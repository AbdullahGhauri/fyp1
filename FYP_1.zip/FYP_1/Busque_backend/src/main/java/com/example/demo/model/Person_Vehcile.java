package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Person_Vehcile {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int personVehcileId;
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "personVehcileId", referencedColumnName = "personVehcileId")
	private List<PersonVehcileRoute> personVehcileRoute = new ArrayList<>();

	public Person_Vehcile() {
		super();
	}

	public int getPersonVehcileId() {
		return personVehcileId;
	}

	public void setPersonVehcileId(int personVehcileId) {
		this.personVehcileId = personVehcileId;
	}

	
	public List<PersonVehcileRoute> getPersonVehcileRoute() {
		return personVehcileRoute;
	}

	public void setPersonVehcileRoute(List<PersonVehcileRoute> personVehcileRoute) {
		this.personVehcileRoute = personVehcileRoute;
	}

	@Override
	public String toString() {
		return "Person_Vehcile [personVehcileId=" + personVehcileId + ", personVehcileRoute=" + personVehcileRoute
				+ "]";
	}

	
	
	
	
}
