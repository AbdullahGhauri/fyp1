package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Place {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int placeId;
	

	@Column(name = "place_name")
	private String placeName;
	

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "placeId", referencedColumnName = "placeId")
	private List<RoutePlace> routePlace = new ArrayList<>();


	public Place(String placeName) {
		super();
		this.placeName = placeName;
	}


	public int getPlaceId() {
		return placeId;
	}


	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}


	public String getPlaceName() {
		return placeName;
	}


	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}


	public List<RoutePlace> getRoutePlace() {
		return routePlace;
	}


	public void setRoutePlace(List<RoutePlace> routePlace) {
		this.routePlace = routePlace;
	}


	@Override
	public String toString() {
		return "Place [placeId=" + placeId + ", placeName=" + placeName + ", routePlace=" + routePlace + "]";
	}
	
	

}
