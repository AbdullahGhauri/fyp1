module.exports = require("@nativescript/webpack/lib/before-checkForChanges.js");
