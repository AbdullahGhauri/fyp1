module.exports = require("@nativescript/webpack/lib/after-prepare.js");
