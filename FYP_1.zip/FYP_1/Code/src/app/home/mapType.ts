  export enum MapType {

    Physical = 1,
    Satellite = 2,
    Hybrid = 4
  }
