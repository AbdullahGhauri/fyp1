import { Component, ElementRef, ViewChild, OnInit } from "@angular/core";
import { RadSideDrawer } from "nativescript-ui-sidedrawer";
import { Application, isAndroid } from "@nativescript/core";
import {registerElement} from "@nativescript/angular";
import {getCurrentLocation, enableLocationRequest} from "@nativescript/geolocation";
import { Enums } from "@nativescript/core";
import { MapView, Marker, Position } from "nativescript-google-maps-sdk";
import { MapType } from "./mapType";

registerElement("MapView", () => require("nativescript-google-maps-sdk").MapView);


@Component({
    selector: "Home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.scss']
    
})
export class HomeComponent implements OnInit {

    private mapView: MapView;
    
    public latitude = 25.1035235;
    public longitude = 67.4019008;
    public zoom = 14;

    flag = false;

    mapOptionsVisible = false;
    mapType = MapType;
    selectedMapType = this.mapType.Physical;


    constructor() {
        // Use the component constructor to inject providers.
    }

    ngOnInit(): void {
        // Init your component properties here.
        // setTimeout(() => {
        //     this.flag = true;
        // }, 1000)
       
    }

    onMapReady (event) {
        this.mapView = event.object;
        // enableLocationRequest().then(() => {

        getCurrentLocation({desiredAccuracy: Enums.Accuracy.high}).then((result) => {
            // console.log(result)
            // setTimeout(()=> {
                this.latitude = result.latitude;
                this.longitude = result.longitude;
                const marker = new Marker()
                marker.position = Position.positionFromLatLng(this.latitude, this.longitude);
                this.mapView.addMarker(marker);

            // })
        }).catch((err)=>{console.log(err)})
    // }).catch((err)=>{console.log(err)})

    };

    onDrawerButtonTap(): void {
        const sideDrawer = <RadSideDrawer>Application.getRootView();
        sideDrawer.showDrawer();
    }

    toggleMapOptions() {
        this.mapOptionsVisible = !this.mapOptionsVisible;
      }
    
    switchMap(type) {
          
        this.setMapType(type);
        this.selectedMapType = type;
    }

    setMapType(type: number) {
        if (isAndroid) {
          this.mapView.gMap.setMapType(type);
        } else {
          this.mapView.gMap.mapType = type;
        }
      }
}
